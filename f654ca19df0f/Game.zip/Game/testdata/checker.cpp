#include "testlib.h"
#include<bits/stdc++.h>
using namespace std;
const int maxn=2e3;
int test;
int n,m,K;
bool vis[maxn+5];
signed main(int argc,char* argv[]){
	registerInteraction(argc,argv);
	registerGen(argc,argv,1);
	random_device rd;
	rnd.setSeed(rd());
	test=inf.readInt();
	cout<<test<<endl;
	n=inf.readInt(),m=inf.readInt(),K=inf.readInt();
	cout<<n<<" "<<m<<" "<<K<<endl;
	int x=rnd.next(1,n),xx;
	int lft=5e4;
	int nxt=0;
	if(test!=1) nxt=rnd.next(1,K);
	int T,y;
	while(lft--){
		memset(vis,0,sizeof(vis));
		T=ouf.readInt(0,n);
		if(!T) break;
		while(T--){
			y=ouf.readInt(1,n);
			if(vis[y])
				quitf(_wa,"There are repeating elements in the collection");
			vis[y]=1;
		}
		if(nxt>1){//Tell lie
			xx=rnd.next(1,n-1);
			if(xx>=x) xx++;
			nxt--;
		} 
		else if(nxt==1){//Tell false
			for(xx=1;xx<=n;xx++)
				if(vis[xx]!=vis[x]) break;
			nxt--;
		}
		else{//Tell true
			xx=x;
			if(test!=1) nxt=rnd.next(1,K);
		}
		if(vis[xx]) cout<<"Yes"<<endl;
		else cout<<"No"<<endl;
	}
	if(T) T=ouf.readInt(0,0);
	memset(vis,0,sizeof(vis));
	T=ouf.readInt(1,m);
	while(T--){
		y=ouf.readInt(1,n);
		if(vis[y])
			quitf(_wa,"There are repeating elements in the collection");
		vis[y]=1;
	}
	if(vis[x]) quitf(_ok,"You win, Alice choose %d",x);
	else quitf(_wa,"You lose, Alice choose %d",x);
	return 0;
}
